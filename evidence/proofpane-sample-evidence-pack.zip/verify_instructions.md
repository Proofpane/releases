# Verifying this evidence pack

You don't need access to the Proofpane backend to verify this bundle.

Requirements:
- Python 3.10+
- `cryptography` package: `pip install cryptography`

Steps:

1. Get the verifier script (single file, no install):
   - From the Proofpane repo: `tools/verify_evidence_pack.py`
   - Or copy from a previous trusted bundle.

2. Run:
   `python3 verify_evidence_pack.py <this-pack>.zip`

3. Expected output on success:
   ```
   ✓ All file hashes match manifest
   ✓ Signature valid (key fingerprint: <16 hex chars>)
   ✓ Audit chain re-verified: N records, all hashes match
   PASS — bundle integrity confirmed.
   ```

If any step fails, the verifier prints WHICH file or row is broken. Refuse
the bundle in that case.
