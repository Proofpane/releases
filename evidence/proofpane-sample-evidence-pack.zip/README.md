# Proofpane Evidence Pack

This archive is an auditor-grade record of governance events from an Proofpane
Orchestrator instance. Every file inside is hashed; the manifest is signed
with Ed25519. Tampering with any file invalidates the bundle.

## Scope

- Time window: beginning of log → export time
- Filters: actor=(any) event_type=(any) skill_id=(any)
- Records included: 16
- Earliest: 2026-07-09T21:38:57.013539Z
- Latest:   2026-07-09T21:38:57.102009Z

## Chain integrity at export

- valid: True
- checked: 16
- broken_at: None
- reason: None

## Compliance coverage

The skills involved in this slice claim coverage of the following
governance/regulatory frameworks. Full per-control evidence is in
`compliance/coverage.json`.

- NIST AI RMF: 3/72 controls covered (4%)
- ISO 42001: 3/86 controls covered (3%)
- EU AI Act: 3/113 controls covered (3%)
- GDPR: 5/26 controls covered (19%)
- SOC 2: 2/38 controls covered (5%)

These mappings are starter content shipped with Proofpane; an organization
should review and ratify them with their own compliance team before
relying on them for external audit.

## AI Use Case inventory + autonomy drift

Each AI use case in the org declares an `autonomy_level` (the human
oversight tier it's supposed to operate at, per EU AI Act Art.14 / NIST
AI RMF Govern-1.4 / ISO 42001 Annex A.6.2.6). Drift means the workflows
linked to the use case have actual HITL configuration that doesn't
match the declared level — e.g. a use case declared "approve every
action" but a workflow has nodes without a HITL gate.

- No AI Use Cases in scope (unscoped export, or empty org).

## Signing key

- Public key fingerprint: `67ff4fa702e8eb1a`
- Stored at: `signatures/public_key.pem`

## How to verify

Use the standalone verifier (no backend access required):

    python3 verify_evidence_pack.py <this-pack>.zip

The verifier:
  1. Re-hashes every file, compares against `manifest.json`.
  2. Verifies the Ed25519 signature in `signatures/manifest.sig`.
  3. Re-walks the audit hash chain inside `audit/records.json`.

Any failure points to the specific file or audit row that doesn't match.

## MCP governance overlay (evidence-pack 1.3)

If the operator runs the Proofpane daemon as an MCP server (Claude Desktop /
Codex Desktop / Cursor / any MCP-aware client), every tool call those
clients make flows through the audit log here with a `mcp.tool_call`
event type. This pack denormalizes those rows into four standalone
files so the auditor can read them without re-walking the canonical
chain:

- `mcp/summary.json` — same rollup as the live `/mcp-activity` dashboard, frozen at export time (`total_calls`, `by_outcome`, `by_policy_rule`, `hitl` counts, `dlp_redactions_total`, plus per-agent / per-tool / per-vendor break-downs)
- `mcp/audit_calls.json` — every `mcp.tool_call` flat: vendor, agent, tool, decision classification, duration, DLP redaction count
- `mcp/hitl_decisions.json` — every `mcp.hitl.*` lifecycle event (requested / approved / rejected / expired) with actor + reason
- `mcp/agent_policies.json` — point-in-time snapshot of every per-agent policy (`allowed_paths`, `denied_paths`, `bash_policy`, `default_decision`) — load-bearing for an auditor reconstructing WHY a specific path matched a deny rule

The summary numbers are mirrored into `manifest.mcp_summary` so they're visible without opening any file.

**Caveat**: agent policies are a snapshot at export, not versioned per-decision. If the operator edits a policy DURING a long audit window, the snapshot only captures the post-edit state. For airtight reconstruction across edits, re-export at the boundary.

## Experiments (doc 21 PR3)

Every completed comparison-style run in the window ships as one row
of `experiments/runs.json` carrying the signed-artifact fields
specified in doc 21 §4: `dimension` + `variants` + `fixture_hash` +
per-variant scores + `verdict` + `significance` (effect_size + CI + n +
is_significant) + `judge_config_hash` + `audit_run_id`. Paired with
the `experiment.*` event chain inside `audit/records.json` — that
chain is authoritative for in-flight runs; this file is the per-run
verdict an auditor reads as one row without replaying audit events.
The `manifest.experiments_summary` block mirrors count + by_dimension
+ by_kind + winners_significant for at-a-glance review.

Each row carries a `kind` field that discriminates which comparator
produced it (the doc 21 §6 step 3 adapter):
- `experiment_primitive` — native Experiment from PR3 (e.g. memory_strategy)
- `gene_sandbox` — proposed/approved Gene with a `sandbox_pass_rate_delta`
  verdict (no fixture_hash; replays raw failing samples by id, listed
  in `derived_from_sample_ids` and traceable via `genes/active.json`)
- future: `cross_vendor_suite`, `compete` (deferred until those services
  acquire a unified storage surface)

A regulator can rebuild "why was variant X picked?" from:
1. The fixture content (re-derivable via `fixture_hash`, persisted in
   `fixtures` table on the live system)
2. The judge config (`judge_config_hash` — NULL for deterministic
   metrics like `fact_retention`)
3. The verdict + significance (in `experiments/runs.json` itself)
4. Every per-variant audit event nested under `audit_run_id` (in
   `audit/records.json`)

Honest caveat: variant outputs are LLM-generated and nondeterministic;
the auditor can re-derive WHAT was compared and HOW it was scored, not
necessarily re-obtain the same scores by re-running.

## Contents

- `audit/records.json` — full audit slice in chronological order
- `audit/verification.json` — chain re-verification at the moment of export
- `audit/chain_anchors.json` — prev/last hashes that anchor this slice into the global log
- `skills/*.json` — snapshot of every skill referenced by the slice
- `compliance/coverage.json` — per-framework / per-control coverage rollup
- `genes/active.json` — org-scoped: every Gene (approved/proposed/deprecated) with full provenance
- `genes/capsule_history.json` — org-scoped: per-skill Capsule history (composed prompts that ran)
- `experiments/runs.json` — org-scoped: every completed Experiment with verdict + significance + fixture_hash
- `use_cases/inventory.json` — every AI Use Case in the org with declared autonomy_level + drift report (org-scoped exports only)
- `mcp/summary.json` — MCP activity rollup (only when slice contains mcp.* events)
- `mcp/audit_calls.json` — flat mcp.tool_call list
- `mcp/hitl_decisions.json` — flat mcp.hitl.* lifecycle log
- `mcp/agent_policies.json` — current per-agent policies (org-scoped)
- `manifest.json` — full file-by-file SHA-256 index (the signed document)
- `signatures/manifest.sig` — raw 64-byte Ed25519 signature over `manifest.json`
- `signatures/public_key.pem` — Ed25519 public key, PEM-encoded

Generated: 2026-07-09T21:38:57.121753Z
